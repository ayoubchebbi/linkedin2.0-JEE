package com.tn.isamm.services;

import java.util.ArrayList;

import com.tn.isamm.beans.User;

public interface UserService {
	boolean addUserService(String email,String password,String first_name,String last_name);
	
	User getUserByEmailPasswordService(String email, String password);
	
	ArrayList<User> getUsersListService(User currentUser);
}
