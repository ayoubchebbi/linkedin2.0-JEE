package com.tn.isamm.services;

import java.util.ArrayList;
import java.util.Collection;

import com.tn.isamm.beans.User;

public interface FriendsService {
    ArrayList<User> getFriendListService(User user);
    void addFriendService(int id1, int id2);
}
