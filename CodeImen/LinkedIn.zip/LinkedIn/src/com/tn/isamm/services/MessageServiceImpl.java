package com.tn.isamm.services;

import java.util.ArrayList;

import com.tn.isamm.beans.Message;
import com.tn.isamm.beans.User;
import com.tn.isamm.dao.MessageDAOImpl;


public class MessageServiceImpl {
	MessageDAOImpl message = new MessageDAOImpl ();
	
	public ArrayList<Message> getAllService (User userOne){
		return message.getAll(userOne);
	}
}
