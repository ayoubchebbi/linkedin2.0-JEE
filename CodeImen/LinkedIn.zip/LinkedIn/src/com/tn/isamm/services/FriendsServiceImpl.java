package com.tn.isamm.services;

import java.util.ArrayList;
import java.util.Collection;

import com.tn.isamm.beans.User;
import com.tn.isamm.dao.FriendsDAO;
import com.tn.isamm.dao.FriendsDAOImpl;

public class FriendsServiceImpl {
	FriendsDAO Friends = new FriendsDAOImpl ();
	
    public ArrayList<User> getFriendListService(User user){
    	return Friends.getFriendList(user);
    }
    
    public void addFriendService(int id1, int id2) {
    	Friends.addFriend(id1,id2);
    }
}
