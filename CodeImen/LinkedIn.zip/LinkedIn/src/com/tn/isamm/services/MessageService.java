package com.tn.isamm.services;

import java.util.ArrayList;

import com.tn.isamm.beans.Message;
import com.tn.isamm.beans.User;

public interface MessageService {
	ArrayList<Message> getAllService (User userOne) ;
}
