package com.tn.isamm.services;

import java.util.ArrayList;

import com.tn.isamm.beans.User;
import com.tn.isamm.dao.UserDAO;
import com.tn.isamm.dao.UserDAOImpl;

public class UserServiceImpl implements UserService{
	UserDAO User = new UserDAOImpl ();
	
	public boolean addUserService(String email,String password,String first_name,String last_name) {
		return User.addUser(email,password,first_name,last_name);
	}
	
	public User getUserByEmailPasswordService(String email, String password) {
		return User.getUserByEmailPassword(email,password);
	}
	
	public ArrayList<User> getUsersListService(User currentUser){
		return User.getUsersList(currentUser);
	}
}
