package com.tn.isamm.beans;

import java.sql.Date;
import java.sql.Timestamp;


public class User {
	private long id;
    private String email;
    private String first_name;
    private String last_name;
    private String name;
    private String sex;
    private boolean isuserfriend;
    private boolean isfriendofuser;
    private Date birth_date;
    private Timestamp reg_date;
    private String phone;

    public User() {
    }

    public User(User user) {
        this.id = user.id;
        this.email = user.email;
        this.first_name = user.first_name;
        this.last_name = user.last_name;
        this.name = user.name;
        this.sex = user.sex;
        this.isuserfriend = user.isuserfriend;
        this.isfriendofuser = user.isfriendofuser;
        this.birth_date = user.birth_date;
        this.reg_date = user.reg_date;
        this.phone = user.phone;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
        this.name = this.first_name + " " + this.last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
        this.name = this.first_name + " " + this.last_name;
    }

    public void setBirth_date(Date birth_date) {
        if (birth_date!=null)
            this.birth_date = Date.valueOf(birth_date.toLocalDate().atStartOfDay().toLocalDate());
    }

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public boolean isIsuserfriend() {
		return isuserfriend;
	}

	public void setIsuserfriend(boolean isuserfriend) {
		this.isuserfriend = isuserfriend;
	}

	public boolean isIsfriendofuser() {
		return isfriendofuser;
	}

	public void setIsfriendofuser(boolean isfriendofuser) {
		this.isfriendofuser = isfriendofuser;
	}

	public Timestamp getReg_date() {
		return reg_date;
	}

	public void setReg_date(Timestamp reg_date) {
		this.reg_date = reg_date;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getFirst_name() {
		return first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public Date getBirth_date() {
		return birth_date;
	}
    
}
