package com.tn.isamm.beans;

import java.sql.Timestamp;

public class Message {
	 private long id;
	    private Timestamp date;
	    private long sender;
	    private long recipient;
	    private String body;
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public Timestamp getDate() {
			return date;
		}
		public void setDate(Timestamp date) {
			this.date = date;
		}
		public long getSender() {
			return sender;
		}
		public void setSender(long sender) {
			this.sender = sender;
		}
		public long getRecipient() {
			return recipient;
		}
		public void setRecipient(long recipient) {
			this.recipient = recipient;
		}
		public String getBody() {
			return body;
		}
		public void setBody(String body) {
			this.body = body;
		}
}
