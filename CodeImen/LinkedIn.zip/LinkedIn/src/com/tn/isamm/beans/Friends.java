package com.tn.isamm.beans;

public class Friends {
	 private int id;
	 private long userid;
	 private long friendid;
	 
	
	    
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public long getUserid() {
		return userid;
	}
	public void setUserid(long userid) {
		this.userid = userid;
	}
	public long getFriendid() {
		return friendid;
	}
	public void setFriendid(long friendid) {
		this.friendid = friendid;
	}
	    
}
