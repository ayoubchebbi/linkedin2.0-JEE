package com.tn.isamm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.tn.isamm.beans.Message;
import com.tn.isamm.beans.User;



public class MessageDAOImpl {
	
	public ArrayList<Message> getAll(User userOne) {
		
        System.out.println("DAO users");
    	DBConnexion db = new DBConnexion();
		Connection connexion = db.DBConnect();
		ArrayList<Message> al = new ArrayList<Message>();
		
        try {
        	//OR (recipient = ?) 
        	String sql = "SELECT * FROM `message` WHERE (sender = ?) Group By recipient ORDER BY date DESC Limit 1";
        	
        	PreparedStatement prepare = connexion.prepareStatement(sql);
        	System.out.println("userOne id "+ userOne.getId());
        	//System.out.println("userTwo id "+ userOne.getId());
            prepare.setLong(1, userOne.getId());
           // prepare.setLong(2, userOne.getId());
           
            ResultSet result = prepare.executeQuery();
            
            while (result.next()) {
            	System.out.println("it�ration");
            	Message message = new Message();
            
            	message.setDate(result.getTimestamp("date"));
            	message.setSender(result.getInt("sender"));
            	message.setRecipient(result.getInt("recipient"));
            	message.setBody(result.getString("body"));
            	

            	al.add(message);
            }
            
       
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return al;
    	
    

    }
}
