package com.tn.isamm.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnexion {
	
	public Connection DBConnect() {
		String url = "jdbc:mysql://localhost:3307/db-schema";
    	String utilisateur = "root";
    	String motDePasse = "";
    	Connection connexion = null;
    	
        int resultat=0;
    	 System.out.println( "Connexion en cours" );
    	 try {
				Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	
    	try {
    		
    	    connexion = DriverManager.getConnection(url, utilisateur, motDePasse);
    	    System.out.println( "Driver found !" );

    	} catch ( SQLException e ) {
    	} 
    	
   
        System.out.println( "Objet requ�te cr�� !" );
		return connexion;
	}

}
