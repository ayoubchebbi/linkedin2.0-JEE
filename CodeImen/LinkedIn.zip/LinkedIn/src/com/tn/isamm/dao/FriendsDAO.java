package com.tn.isamm.dao;

import java.util.ArrayList;
import java.util.Collection;

import com.tn.isamm.beans.User;

public interface FriendsDAO {
	void addFriend(int id1, int id2);
   /* void removeFriend(User user, User friend);
    long getNumberOfFriends(User user, String searchText);*/
    ArrayList<User> getFriendList(User user);

}
