package com.tn.isamm.dao;

import java.util.ArrayList;

import com.tn.isamm.beans.User;

public interface UserDAO {
	
	boolean addUser(String email,String password,String first_name,String last_name);
	
	User getUserByEmailPassword(String email, String password);
	
	ArrayList<User> getUsersList(User currentUser);
}
