package com.tn.isamm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;

import com.tn.isamm.beans.User;



public class FriendsDAOImpl implements FriendsDAO{

    public void addFriend(int id1, int id2) {
    	DBConnexion db = new DBConnexion();
		Connection connexion = db.DBConnect();

       
        try {
        	String sql = "INSERT INTO `friends` (userid,friendid) VALUES (?,?)";
        	
        	PreparedStatement prepare = connexion.prepareStatement(sql);
            
            prepare.setInt(1, id1);
            prepare.setInt(2, id2);
            

            prepare.executeUpdate();
       
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }
/*
    @Override
    default void removeFriend(User user, User friend) {
        final String SQL_REMOVE_FRIEND =
                "DELETE FROM friends WHERE userid = ? AND friendid = ?;";

        delete(SQL_REMOVE_FRIEND, user.getId(), friend.getId());
    }

    @Override
    default long getNumberOfFriends(User user, String searchText) {
        final String SQL_GET_NUMBER_OF_FRIENDS =
                "SELECT count(friendid) AS id FROM friends "
                        .concat("WHERE friends.userid = ?;");
        final String SQL_GET_NUMBER_OF_FRIENDS_WITH_SEARCH_PARAMETER =
                "SELECT count(id) AS id FROM users "
                        .concat("INNER JOIN friends AS userfriends ON users.id = userfriends.friendid AND userfriends.userid = ? ")
                        .concat("WHERE LOWER(CONCAT_WS(' ', first_name, last_name)) LIKE LOWER(?) ");
        final Optional<LongBean> bean;

        if (searchText==null || searchText.isEmpty())
            bean = select(LongBean.class, SQL_GET_NUMBER_OF_FRIENDS, user.getId());
        else
            bean = select(LongBean.class, SQL_GET_NUMBER_OF_FRIENDS_WITH_SEARCH_PARAMETER, user.getId(), "%" + searchText + "%");
        return bean.get().getId();

    }*/

    
    public ArrayList<User> getFriendList(User currentUser) {
    	System.out.println("DAO friends");
    	DBConnexion db = new DBConnexion();
		Connection connexion = db.DBConnect();
		ArrayList<User> al = new ArrayList<User>();
		
        try {
        	String sql = "SELECT * FROM `users`,`friends` WHERE users.id = friends.friendid and friends.userid = ?";
        	
        	PreparedStatement prepare = connexion.prepareStatement(sql);
        	System.out.println("current user id "+ currentUser.getId());
            prepare.setLong(1, currentUser.getId());
        
           
           
            ResultSet result = prepare.executeQuery();
            
            while (result.next()) {
            	System.out.println("it�ration");
            	User user = new User();
            	System.out.println("amis "+ result.getString("email"));
            	//user.setId(result.getInt("id"));
            	user.setFirst_name(result.getString("first_name"));
            	user.setLast_name(result.getString("last_name"));
            	user.setEmail(result.getString("email"));
            	user.setPhone(result.getString("phone"));
            	user.setBirth_date(result.getDate("birth_date"));
            	user.setSex(result.getString("sex"));
            	al.add(user);
            }
            
       
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return al;
    	
    	
    }
}
