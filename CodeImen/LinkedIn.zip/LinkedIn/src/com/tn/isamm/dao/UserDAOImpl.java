package com.tn.isamm.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Optional;

import com.tn.isamm.beans.User;



public class UserDAOImpl implements UserDAO{
	
	public boolean addUser(String email,String password,String first_name,String last_name) {

		DBConnexion db = new DBConnexion();
		Connection connexion = db.DBConnect();

       
        try {
        	String sql = "INSERT INTO `users` (email, password, first_name, last_name) VALUES (?,?,?,?)";
        	
        	PreparedStatement prepare = connexion.prepareStatement(sql);
            
            prepare.setString(1, email);
            prepare.setString(2, password);
            prepare.setString(3, first_name);
            prepare.setString(4, last_name);

            prepare.executeUpdate();
       
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    	    
		return true;
	}
	
 
    public User getUserByEmailPassword(String email, String password) {
    	System.out.println("DAO email "+email);
    	System.out.println("DAO password "+password);
        
        DBConnexion db = new DBConnexion();
		Connection connexion = db.DBConnect();

		User user = new User();
        try {
        	String sql = "SELECT * FROM `users` WHERE email = ? AND password = ?";
        	
        	PreparedStatement prepare = connexion.prepareStatement(sql);
            
            prepare.setString(1, email);
            prepare.setString(2, password);
           
           
            ResultSet result = prepare.executeQuery();
            user.setId(0);
            while (result.next()) {
            	user.setId(result.getInt("id"));
            	user.setFirst_name(result.getString("first_name"));
            	user.setLast_name(result.getString("last_name"));
            	user.setEmail(result.getString("email"));
            	user.setPhone(result.getString("phone"));
            	//user.setReg_date(result.getTimestamp("reg_date"));
            	user.setBirth_date(result.getDate("birth_date"));
            	user.setSex(result.getString("sex"));
            	
            }
            
       
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return user;
    }
    
    public ArrayList<User> getUsersList(User currentUser) {
    	System.out.println("DAO users");
    	DBConnexion db = new DBConnexion();
		Connection connexion = db.DBConnect();
		ArrayList<User> al = new ArrayList<User>();
		
        try {
        	String sql = "SELECT * FROM `users` WHERE users.id != ? AND users.id NOT IN (SELECT users.id FROM `users`,`friends` WHERE users.id = friends.friendid and friends.userid = ?)";
        	
        	PreparedStatement prepare = connexion.prepareStatement(sql);
        	System.out.println("current user id "+ currentUser.getId());
            prepare.setLong(1, currentUser.getId());
            prepare.setLong(2, currentUser.getId());
           
           
            ResultSet result = prepare.executeQuery();
            
            while (result.next()) {
            	System.out.println("it�ration");
            	User user = new User();
            	System.out.println("amis "+ result.getString("email"));
            	user.setId(result.getInt("id"));
            	user.setFirst_name(result.getString("first_name"));
            	user.setLast_name(result.getString("last_name"));
            	user.setEmail(result.getString("email"));
            	user.setPhone(result.getString("phone"));
            	user.setBirth_date(result.getDate("birth_date"));
            	user.setSex(result.getString("sex"));
            	al.add(user);
            }
            
       
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return al;
    	
    	
    }
}
