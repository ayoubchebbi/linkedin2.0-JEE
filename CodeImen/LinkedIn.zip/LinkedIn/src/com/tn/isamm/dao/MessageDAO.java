package com.tn.isamm.dao;

import java.util.ArrayList;

import com.tn.isamm.beans.Message;
import com.tn.isamm.beans.User;

public interface MessageDAO {
	ArrayList<Message> getAll(User userOne, User userTwo) ;
}
