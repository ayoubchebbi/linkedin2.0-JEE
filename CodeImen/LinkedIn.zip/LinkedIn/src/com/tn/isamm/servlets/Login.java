package com.tn.isamm.servlets;



import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tn.isamm.beans.User;
import com.tn.isamm.services.UserService;
import com.tn.isamm.services.UserServiceImpl;



/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.getRequestDispatcher("/WEB-INF/login.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 //final HttpSessionWrapper session = request::getSession;
	        final String email = request.getParameter("email");
	        final String password = request.getParameter("password");

	      /*  //Validate input parameters
	        ValidationCode validationCode = validateLogin(email, password);
	        if (!isValidCode(validationCode)) {
	            showError(getMessage(validationCode, session.getLocale()), request, response);
	            return;
	        }
*/
	        //Check if login is correct
	        UserService userService = new UserServiceImpl ();
	        User user = new User();
	        user =  userService.getUserByEmailPasswordService(email,password);
	        System.out.println("id   "+user.getId());
			
	       
	       if (user.getId() != 0){

	            System.out.println(String.format("Login \"%s\" successful", email));
	 
	            HttpSession session = request.getSession();
	            session.setAttribute("user",user) ;
	            
	
	            request.getRequestDispatcher("/Acceuil").forward(request, response);
	        } else {

	        	System.out.println("incorrect");
	        	doGet(request, response);
	        	   /*
	        	user = userDao.getUserByEmail(email);
	            if (!user.isPresent())
	                validationCode = ValidationCode.USER_NOT_FOUND;
	            else
	                validationCode = ValidationCode.PASS_INCORRECT;
	            showError(getMessage(validationCode, session.getLocale()), request, response);
	            */
	        	// request.getRequestDispatcher("/Login").forward(request, response);
	        }

	}

}
