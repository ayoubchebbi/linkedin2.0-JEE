package com.tn.isamm.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tn.isamm.beans.User;
import com.tn.isamm.services.UserService;
import com.tn.isamm.services.UserServiceImpl;

/**
 * Servlet implementation class registration
 */
@WebServlet("/registration")
public class registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public registration() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.getRequestDispatcher("/WEB-INF/registration.jsp").forward(request, response);
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		//final HttpSessionWrapper session = request::getSession;
        final String email = request.getParameter("email");
        final String password = request.getParameter("password");
        final String confirm_password = request.getParameter("confirm_password");
        final String first_name = request.getParameter("first_name");
        final String last_name = request.getParameter("last_name");
       // Optional<User> user;

        //Validate input parameters
      /*  ValidationCode validationCode = validateRegistration(email, password, confirm_password, first_name, last_name);
        if (!isValidCode(validationCode)) {
            showError(getMessage(validationCode, session.getLocale()), request, response);
            return;
        }*/

        //Check if user is already registered
        //a ajouyterrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
       /* user = userDao.getUserByEmail(email);
        if (user.isPresent()) {
            showError(getMessage(ValidationCode.DUPLICATED_REGISTRATION, session.getLocale()), request, response);
            return;
        }*/

        //Add new user
        /*User sessionUser = userDao.addUser(email, password, first_name, last_name).get();
        System.out.println(String.format("User \"%s\" successfully registered", email));
        session.setUser(sessionUser);
        response.sendRedirect("/profile?id=" + sessionUser.getId());
*/
		UserService user2 = new UserServiceImpl ();
		user2.addUserService(email,password,first_name,last_name);
		
		UserService userService = new UserServiceImpl ();
        User user = new User();
        user =  userService.getUserByEmailPasswordService(email,password);
        request.setAttribute("user", user);
        request.getRequestDispatcher("/Acceuil").forward(request, response);
	}

}
